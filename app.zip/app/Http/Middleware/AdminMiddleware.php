<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    /**
     * Allow only authenticated administrators
     * to access protected routes.
     */
    public function handle(Request $request, Closure $next): Response
    {
        /*
         * The user must be logged in.
         */
        if (!auth()->check()) {
            abort(403, 'Unauthorized access.');
        }

        /*
         * The logged-in user must have the admin role.
         */
        if (auth()->user()->role !== 'admin') {
            abort(403, 'Administrator access required.');
        }

        return $next($request);
    }
}