<?php

namespace App\Http\Controllers;

use App\Models\Bill;
use App\Models\MeterReading;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class BillController extends Controller
{
    /**
     * Display all bills.
     */
    public function index()
    {
        $bills = Bill::with('customer', 'meterReading.meter')
            ->latest('billing_date')
            ->paginate(10);

        return view('bills.index', compact('bills'));
    }

    /**
     * Show the form for creating a bill.
     */
    public function create()
    {
        $readings = MeterReading::with('meter.customer')
            ->whereDoesntHave('bill')
            ->latest('reading_date')
            ->get();

        return view('bills.create', compact('readings'));
    }

    /**
     * Store a new bill.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'meter_reading_id' => 'required|exists:meter_readings,id',
            'billing_date' => 'required|date',
        ]);

        $reading = MeterReading::with('meter.customer')
            ->findOrFail($validated['meter_reading_id']);

        if ($reading->bill) {
            return back()
                ->withErrors([
                    'meter_reading_id' =>
                        'A bill has already been generated for this meter reading.',
                ])
                ->withInput();
        }

        $consumption = round(
            (float) $reading->consumption,
            2
        );

        // Fixed water tariff: KSh 120.00 per unit.
        $ratePerUnit = 120.00;

        $waterCharge = round(
            $consumption * $ratePerUnit,
            2
        );

        $status = $waterCharge > 0
            ? 'unpaid'
            : 'paid';

        $bill = Bill::create([
            'customer_id' => $reading->meter->customer_id,
            'meter_reading_id' => $reading->id,
            'billing_date' => $validated['billing_date'],
            'consumption' => $consumption,
            'rate_per_unit' => $ratePerUnit,
            'water_charge' => $waterCharge,
            'status' => $status,
            'amount_paid' => 0,
            'balance' => $waterCharge,
        ]);

        return redirect()
            ->route('bills.show', $bill)
            ->with(
                'success',
                'Bill generated successfully. Your invoice is ready to view or download.'
            );
    }

    /**
     * Display one bill.
     */
    public function show(Bill $bill)
    {
        $bill->load(
            'customer',
            'meterReading.meter',
            'payments'
        );

        return view(
            'bills.show',
            compact('bill')
        );
    }

    /**
     * Download one bill as PDF.
     */
    public function pdf(Bill $bill)
    {
        $bill->load([
            'customer',
            'meterReading.meter',
            'payments',
        ]);

        $pdf = Pdf::loadView(
            'bills.pdf',
            compact('bill')
        )->setPaper(
            'a4',
            'portrait'
        );

        return $pdf->download(
            $bill->invoice_number . '.pdf'
        );
    }

    /**
     * Display all outstanding bills in the browser.
     *
     * This is a read-only report.
     *
     * It does not create, update, or delete:
     * - Bills
     * - Payments
     * - Customers
     * - M-PESA transactions
     */
    public function outstanding()
    {
        $report = $this->getOutstandingReportData();

        return view(
            'bills.outstanding',
            $report
        );
    }

    /**
     * Download all outstanding bills as a PDF report.
     *
     * This method is read-only.
     *
     * It does not create, update, or delete:
     * - Bills
     * - Payments
     * - Customers
     * - M-PESA transactions
     */
    public function outstandingPdf()
    {
        $report = $this->getOutstandingReportData();

        $pdf = Pdf::loadView(
            'bills.outstanding-pdf',
            $report
        )->setPaper(
            'a4',
            'portrait'
        );

        return $pdf->download(
            'Outstanding-Bills-' . now()->format('Y-m-d') . '.pdf'
        );
    }

    /**
     * Prepare all data used by both:
     * - Outstanding Bills browser report
     * - Outstanding Bills PDF report
     *
     * The returned variables intentionally use the data types
     * expected by the browser and PDF Blade templates.
     */
    private function getOutstandingReportData(): array
    {
        /*
        |--------------------------------------------------------------------------
        | Get Outstanding Bills
        |--------------------------------------------------------------------------
        */

        $bills = Bill::with([
            'customer',
            'meterReading.meter',
            'payments',
        ])
            ->whereIn('status', [
                'unpaid',
                'partially_paid',
            ])
            ->where('balance', '>', 0)
            ->orderByDesc('billing_date')
            ->orderBy('customer_id')
            ->get();

        /*
        |--------------------------------------------------------------------------
        | Group Bills By Customer
        |--------------------------------------------------------------------------
        */

        $customersWithBalances = $bills
            ->groupBy('customer_id')
            ->map(function ($customerBills) {

                $customer = $customerBills->first()->customer;

                if (!$customer) {
                    return null;
                }

                /*
                |--------------------------------------------------------------------------
                | Customer Financial Totals
                |--------------------------------------------------------------------------
                */

                $totalBilled = round(
                    (float) $customerBills->sum('water_charge'),
                    2
                );

                $totalPaid = round(
                    (float) $customerBills->sum('amount_paid'),
                    2
                );

                $totalOutstanding = round(
                    (float) $customerBills->sum('balance'),
                    2
                );

                /*
                |--------------------------------------------------------------------------
                | Process Customer Bills
                |--------------------------------------------------------------------------
                */

                $runningPreviousBalance = 0;

                $processedBills = $customerBills
                    ->sortBy('billing_date')
                    ->values()
                    ->map(function ($bill) use (&$runningPreviousBalance) {

                        $bill->report_previous_balance = round(
                            $runningPreviousBalance,
                            2
                        );

                        $bill->report_outstanding = round(
                            (float) $bill->balance,
                            2
                        );

                        $runningPreviousBalance = round(
                            $runningPreviousBalance +
                            $bill->report_outstanding,
                            2
                        );

                        return $bill;
                    });

                /*
                |--------------------------------------------------------------------------
                | Attach Report Values To Customer
                |--------------------------------------------------------------------------
                */

                $customer->report_total_billed = $totalBilled;
                $customer->report_total_paid = $totalPaid;
                $customer->report_outstanding = $totalOutstanding;

                /*
                |--------------------------------------------------------------------------
                | Make Processed Bills Available As $customer->bills
                |--------------------------------------------------------------------------
                */

                $customer->setRelation(
                    'bills',
                    $processedBills
                );

                return $customer;
            })
            ->filter()
            ->values();

        /*
        |--------------------------------------------------------------------------
        | Outstanding Bills Collection
        |--------------------------------------------------------------------------
        |
        | The Blade uses:
        |
        | $outstandingBills->count()
        |
        | Therefore this must remain a Collection.
        |
        */

        $outstandingBills = $bills;

        /*
        |--------------------------------------------------------------------------
        | Numeric Summary Values
        |--------------------------------------------------------------------------
        */

        $customerCount = $customersWithBalances->count();

        $outstandingBillCount = $outstandingBills->count();

        $totalBilled = round(
            (float) $bills->sum('water_charge'),
            2
        );

        $totalPaid = round(
            (float) $bills->sum('amount_paid'),
            2
        );

        $totalOutstanding = round(
            (float) $bills->sum('balance'),
            2
        );

        /*
        |--------------------------------------------------------------------------
        | Collection Percentage
        |--------------------------------------------------------------------------
        */

        $collectionPercentage = $totalBilled > 0
            ? round(
                min(
                    100,
                    ($totalPaid / $totalBilled) * 100
                ),
                1
            )
            : 0;

        /*
        |--------------------------------------------------------------------------
        | Outstanding Percentage
        |--------------------------------------------------------------------------
        */

        $outstandingPercentage = round(
            max(
                0,
                100 - $collectionPercentage
            ),
            1
        );

        /*
        |--------------------------------------------------------------------------
        | Return Report Data
        |--------------------------------------------------------------------------
        */

        return [
            /*
             * Numeric customer count.
             *
             * Used by the Blade as:
             * {{ $customers }}
             */
            'customers' => $customerCount,

            /*
             * Customer collection.
             *
             * Used by the Blade as:
             * {{ $customersWithBalances->count() }}
             * @foreach($customersWithBalances as $customer)
             */
            'customersWithBalances' => $customersWithBalances,

            /*
             * Outstanding bills collection.
             *
             * Used by the Blade as:
             * {{ $outstandingBills->count() }}
             */
            'outstandingBills' => $outstandingBills,

            /*
             * Numeric outstanding bill count.
             *
             * Available if needed by another view.
             */
            'outstandingBillCount' => $outstandingBillCount,

            /*
             * Financial totals.
             */
            'totalBilled' => $totalBilled,
            'totalPaid' => $totalPaid,
            'totalOutstanding' => $totalOutstanding,

            /*
             * Collection percentages.
             */
            'collectionPercentage' => $collectionPercentage,
            'outstandingPercentage' => $outstandingPercentage,
        ];
    }

    /**
     * Show the form for editing a bill.
     */
    public function edit(Bill $bill)
    {
        $bill->load(
            'customer',
            'meterReading.meter',
            'payments'
        );

        return view(
            'bills.edit',
            compact('bill')
        );
    }

    /**
     * Update a bill.
     */
    public function update(Request $request, Bill $bill)
    {
        $validated = $request->validate([
            'billing_date' => 'required|date',
        ]);

        // Fixed water tariff: KSh 120.00 per unit.
        $ratePerUnit = 120.00;

        $consumption = round(
            (float) $bill->consumption,
            2
        );

        $waterCharge = round(
            $consumption * $ratePerUnit,
            2
        );

        /*
        |--------------------------------------------------------------------------
        | Calculate Actual Amount Paid
        |--------------------------------------------------------------------------
        */

        $amountPaid = round(
            (float) $bill->payments()->sum('amount'),
            2
        );

        $appliedAmount = min(
            $amountPaid,
            $waterCharge
        );

        $balance = round(
            max(
                0,
                $waterCharge - $appliedAmount
            ),
            2
        );

        /*
        |--------------------------------------------------------------------------
        | Determine Bill Status
        |--------------------------------------------------------------------------
        */

        if ($balance <= 0 && $waterCharge > 0) {
            $status = 'paid';
        } elseif ($appliedAmount > 0) {
            $status = 'partially_paid';
        } elseif ($waterCharge <= 0) {
            $status = 'paid';
        } else {
            $status = 'unpaid';
        }

        /*
        |--------------------------------------------------------------------------
        | Update Bill
        |--------------------------------------------------------------------------
        */

        $bill->update([
            'billing_date' => $validated['billing_date'],
            'rate_per_unit' => $ratePerUnit,
            'water_charge' => $waterCharge,
            'amount_paid' => $appliedAmount,
            'balance' => $balance,
            'status' => $status,
        ]);

        return redirect()
            ->route('bills.show', $bill)
            ->with(
                'success',
                'Bill updated successfully. Payment totals were recalculated from the payment history.'
            );
    }

    /**
     * Delete a bill.
     */
    public function destroy(Bill $bill)
    {
        $bill->delete();

        return redirect()
            ->route('bills.index')
            ->with(
                'success',
                'Bill deleted successfully.'
            );
    }
}