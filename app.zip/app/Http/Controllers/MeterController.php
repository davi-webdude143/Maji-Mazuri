<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Meter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class MeterController extends Controller
{
    /**
     * Display all meters.
     */
    public function index()
    {
        $meters = Meter::with('customer')
            ->latest()
            ->paginate(10);

        return view('meters.index', compact('meters'));
    }

    /**
     * Show the form for adding a meter.
     */
    public function create()
    {
        $customers = Customer::where('status', 'active')
            ->orderBy('full_name')
            ->get();

        return view('meters.create', compact('customers'));
    }

    /**
     * Store a new meter.
     *
     * Meter numbers are automatically generated as:
     * MTR-0001, MTR-0002, MTR-0003, etc.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'installation_date' => 'nullable|date',
            'initial_reading' => 'required|numeric|min:0',
            'status' => 'required|in:active,inactive',
        ]);

        /*
        |--------------------------------------------------------------------------
        | Only one active meter per customer
        |--------------------------------------------------------------------------
        */

        if ($validated['status'] === 'active') {
            $existingActiveMeter = Meter::where(
                'customer_id',
                $validated['customer_id']
            )
                ->where('status', 'active')
                ->exists();

            if ($existingActiveMeter) {
                throw ValidationException::withMessages([
                    'customer_id' =>
                        'This customer already has an active water meter. '
                        . 'Deactivate the existing meter before registering another active meter.',
                ]);
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Generate next meter number
        |--------------------------------------------------------------------------
        |
        | Existing:
        | MTR-0001
        | MTR-0002
        |
        | Next:
        | MTR-0003
        |
        */

        $lastMeter = Meter::where(
            'meter_number',
            'like',
            'MTR-%'
        )
            ->orderByRaw(
                "CAST(SUBSTRING(meter_number, 5) AS UNSIGNED) DESC"
            )
            ->first();

        $nextNumber = $lastMeter
            ? ((int) substr($lastMeter->meter_number, 4)) + 1
            : 1;

        $meterNumber = 'MTR-' . str_pad(
            $nextNumber,
            4,
            '0',
            STR_PAD_LEFT
        );

        /*
        |--------------------------------------------------------------------------
        | Set current reading equal to initial reading
        |--------------------------------------------------------------------------
        */

        $validated['meter_number'] = $meterNumber;
        $validated['current_reading'] = $validated['initial_reading'];

        Meter::create($validated);

        return redirect()
            ->route('meters.index')
            ->with(
                'success',
                'Water meter registered successfully. Meter/Account Number: '
                . $meterNumber
            );
    }

    /**
     * Display one meter.
     */
    public function show(Meter $meter)
    {
        $meter->load([
            'customer',
            'readings' => function ($query) {
                $query->latest('reading_date');
            },
        ]);

        return view('meters.show', compact('meter'));
    }

    /**
     * Show the edit meter form.
     */
    public function edit(Meter $meter)
    {
        $customers = Customer::where('status', 'active')
            ->orderBy('full_name')
            ->get();

        /*
        |----------------------------------------------------------------------
        | Make sure the current customer's name remains available
        |----------------------------------------------------------------------
        */

        if (
            $meter->customer &&
            !$customers->contains('id', $meter->customer_id)
        ) {
            $customers->push($meter->customer);
        }

        return view(
            'meters.edit',
            compact('meter', 'customers')
        );
    }

    /**
     * Update a meter.
     */
    public function update(
        Request $request,
        Meter $meter
    ) {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'installation_date' => 'nullable|date',
            'initial_reading' => 'required|numeric|min:0',
            'current_reading' => 'required|numeric|min:0',
            'status' => 'required|in:active,inactive',
        ]);

        /*
        |--------------------------------------------------------------------------
        | Prevent current reading from being lower than initial reading
        |--------------------------------------------------------------------------
        */

        if (
            (float) $validated['current_reading']
            < (float) $validated['initial_reading']
        ) {
            throw ValidationException::withMessages([
                'current_reading' =>
                    'Current reading cannot be lower than the initial reading.',
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Only one active meter per customer
        |--------------------------------------------------------------------------
        */

        if ($validated['status'] === 'active') {
            $existingActiveMeter = Meter::where(
                'customer_id',
                $validated['customer_id']
            )
                ->where('status', 'active')
                ->where('id', '!=', $meter->id)
                ->exists();

            if ($existingActiveMeter) {
                throw ValidationException::withMessages([
                    'customer_id' =>
                        'This customer already has another active water meter. '
                        . 'Deactivate that meter before assigning this meter as active.',
                ]);
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Do not change the meter number
        |--------------------------------------------------------------------------
        |
        | The meter number is automatically generated and should remain
        | permanently attached to this physical meter.
        |
        */

        unset($validated['meter_number']);

        $meter->update($validated);

        return redirect()
            ->route('meters.show', $meter)
            ->with(
                'success',
                'Meter information updated successfully.'
            );
    }

    /**
     * Deactivate a meter.
     */
    public function destroy(Meter $meter)
    {
        $meter->update([
            'status' => 'inactive',
        ]);

        return redirect()
            ->route('meters.index')
            ->with(
                'success',
                'Water meter deactivated successfully.'
            );
    }
}

