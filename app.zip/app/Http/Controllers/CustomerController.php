<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    /**
     * Display all customers.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');

        $customers = Customer::query()
            ->when($search, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->where('full_name', 'like', '%' . $search . '%')
                        ->orWhere('customer_number', 'like', '%' . $search . '%')
                        ->orWhere('phone_number', 'like', '%' . $search . '%')
                        ->orWhere('id_number', 'like', '%' . $search . '%');
                });
            })
            ->latest()
            ->paginate(10)
            ->withQueryString();

        return view('customers.index', compact('customers', 'search'));
    }

    /**
     * Show the add customer form.
     */
    public function create()
    {
        return view('customers.create');
    }

    /**
     * Store a new customer.
     *
     * Customer numbers are automatically generated in the format:
     *
     * M0001
     * M0002
     * M0003
     *
     * The customer number is independent from the water meter number.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'full_name' => 'required|string|max:255',
            'id_number' => 'nullable|string|max:50',
            'phone_number' => 'required|string|max:30',
            'email' => 'nullable|email|max:255',
            'address' => 'nullable|string|max:1000',
            'area' => 'nullable|string|max:255',
            'status' => 'required|in:active,inactive',
        ]);

        /*
        |--------------------------------------------------------------------------
        | Generate Customer Number
        |--------------------------------------------------------------------------
        |
        | Customer numbers are used as the M-PESA PayBill account/reference
        | numbers. They are generated when the customer is registered.
        |
        | Example:
        |
        | Customer 1 → M0001
        | Customer 2 → M0002
        | Customer 3 → M0003
        |
        */

        $lastCustomer = Customer::query()
            ->where('customer_number', 'like', 'M%')
            ->orderByDesc('id')
            ->first();

        if ($lastCustomer && preg_match(
            '/^M(\d+)$/',
            $lastCustomer->customer_number,
            $matches
        )) {
            $nextNumber = (int) $matches[1] + 1;
        } else {
            $nextNumber = 1;
        }

        $validated['customer_number'] =
            'M' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

        $customer = Customer::create($validated);

        return redirect()
            ->route('customers.index')
            ->with(
                'success',
                'Customer registered successfully with account number ' .
                $customer->customer_number . '.'
            );
    }

    /**
     * Display one customer.
     */
    public function show(Customer $customer)
    {
        $customer->load([
            'meter',
            'bills',
            'bills.payments',
        ]);

        return view('customers.show', compact('customer'));
    }

    /**
     * Show the edit customer form.
     */
    public function edit(Customer $customer)
    {
        return view('customers.edit', compact('customer'));
    }

    /**
     * Update a customer.
     *
     * The customer number is intentionally excluded from the update
     * validation so it cannot be changed from the normal edit screen.
     */
    public function update(Request $request, Customer $customer)
    {
        $validated = $request->validate([
            'full_name' => 'required|string|max:255',
            'id_number' => 'nullable|string|max:50',
            'phone_number' => 'required|string|max:30',
            'email' => 'nullable|email|max:255',
            'address' => 'nullable|string|max:1000',
            'area' => 'nullable|string|max:255',
            'status' => 'required|in:active,inactive',
        ]);

        $customer->update($validated);

        return redirect()
            ->route('customers.show', $customer)
            ->with(
                'success',
                'Customer information updated successfully.'
            );
    }

    /**
     * Display customer statement.
     */
    public function statement(Customer $customer)
    {
        $customer->load([
            'meter',
            'bills' => function ($query) {
                $query->orderBy('billing_date');
            },
            'bills.payments' => function ($query) {
                $query->orderBy('payment_date');
            },
        ]);

        $totalBilled = $customer->bills->sum('water_charge');

        $totalPaid = $customer->bills
            ->flatMap(function ($bill) {
                return $bill->payments;
            })
            ->sum('amount');

        $balance = $totalBilled - $totalPaid;

        return view(
            'customers.statement',
            compact(
                'customer',
                'totalBilled',
                'totalPaid',
                'balance'
            )
        );
    }

    /**
     * Deactivate a customer.
     */
    public function destroy(Customer $customer)
    {
        $customer->update([
            'status' => 'inactive',
        ]);

        return redirect()
            ->route('customers.index')
            ->with(
                'success',
                'Customer deactivated successfully.'
            );
    }
}