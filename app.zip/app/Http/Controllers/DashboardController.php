<?php

namespace App\Http\Controllers;

use App\Models\Bill;
use App\Models\Customer;
use App\Models\Meter;
use App\Models\MeterReading;
use App\Models\Payment;
use Carbon\Carbon;

class DashboardController extends Controller
{
    /**
     * Display the main application dashboard.
     */
    public function index()
    {
        /*
        |--------------------------------------------------------------------------
        | Customer Statistics
        |--------------------------------------------------------------------------
        */

        $totalCustomers = Customer::count();

        $activeCustomers = Customer::where('status', 'active')->count();

        $inactiveCustomers = max(
            0,
            $totalCustomers - $activeCustomers
        );


        /*
        |--------------------------------------------------------------------------
        | Meter Statistics
        |--------------------------------------------------------------------------
        */

        $totalMeters = Meter::count();

        $activeMeters = Meter::where('status', 'active')->count();


        /*
        |--------------------------------------------------------------------------
        | Meter Reading Statistics
        |--------------------------------------------------------------------------
        */

        $totalReadings = MeterReading::count();


        /*
        |--------------------------------------------------------------------------
        | Billing Statistics
        |--------------------------------------------------------------------------
        */

        $totalBills = Bill::count();

        $totalBilled = (float) Bill::sum('water_charge');

        $paidBills = Bill::where('balance', '<=', 0)->count();

        $unpaidBills = Bill::where('balance', '>', 0)->count();

        $outstandingBalance = max(
            0,
            (float) Bill::sum('balance')
        );


        /*
        |--------------------------------------------------------------------------
        | Payment Statistics
        |--------------------------------------------------------------------------
        */

        $totalPaid = (float) Payment::sum('amount');


        /*
        |--------------------------------------------------------------------------
        | This Month Revenue
        |--------------------------------------------------------------------------
        */

        $thisMonthRevenue = (float) Payment::whereMonth(
                'payment_date',
                now()->month
            )
            ->whereYear(
                'payment_date',
                now()->year
            )
            ->sum('amount');


        /*
        |--------------------------------------------------------------------------
        | Monthly Revenue
        |--------------------------------------------------------------------------
        |
        | Creates revenue figures for January - December
        | for the current year.
        |
        */

        $currentYear = now()->year;

        $monthlyRevenue = [];

        for ($month = 1; $month <= 12; $month++) {

            $monthlyRevenue[] = (float) Payment::whereMonth(
                    'payment_date',
                    $month
                )
                ->whereYear(
                    'payment_date',
                    $currentYear
                )
                ->sum('amount');
        }


        /*
        |--------------------------------------------------------------------------
        | Recent Unpaid Bills
        |--------------------------------------------------------------------------
        */

        $recentUnpaidBills = Bill::with([
                'customer',
                'meterReading.meter'
            ])
            ->where('balance', '>', 0)
            ->latest('billing_date')
            ->take(5)
            ->get();


        /*
        |--------------------------------------------------------------------------
        | Recent Bills
        |--------------------------------------------------------------------------
        */

        $recentBills = Bill::with('customer')
            ->latest('billing_date')
            ->take(5)
            ->get();


        /*
        |--------------------------------------------------------------------------
        | Recent Payments
        |--------------------------------------------------------------------------
        */

        $recentPayments = Payment::with([
                'bill',
                'customer'
            ])
            ->latest('payment_date')
            ->take(5)
            ->get();


        /*
        |--------------------------------------------------------------------------
        | Send Data To Dashboard
        |--------------------------------------------------------------------------
        */

        return view('dashboard', compact(
            'totalCustomers',
            'activeCustomers',
            'inactiveCustomers',

            'totalMeters',
            'activeMeters',

            'totalReadings',

            'totalBills',
            'totalBilled',
            'paidBills',
            'unpaidBills',
            'outstandingBalance',

            'totalPaid',
            'thisMonthRevenue',

            'monthlyRevenue',
            'currentYear',

            'recentUnpaidBills',
            'recentBills',
            'recentPayments'
        ));
    }
}