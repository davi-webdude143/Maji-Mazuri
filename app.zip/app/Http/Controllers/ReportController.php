<?php

namespace App\Http\Controllers;

use App\Models\Bill;
use App\Models\Payment;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    /**
     * Display the reports dashboard.
     */
    public function index(Request $request)
    {
        /*
        |--------------------------------------------------------------------------
        | Date Filters
        |--------------------------------------------------------------------------
        */

        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');


        /*
        |--------------------------------------------------------------------------
        | Billing Report
        |--------------------------------------------------------------------------
        */

        $billsQuery = Bill::query();

        if ($startDate) {
            $billsQuery->whereDate('billing_date', '>=', $startDate);
        }

        if ($endDate) {
            $billsQuery->whereDate('billing_date', '<=', $endDate);
        }

        $bills = $billsQuery
            ->with('customer')
            ->latest('billing_date')
            ->get();


        /*
        |--------------------------------------------------------------------------
        | Payment Report
        |--------------------------------------------------------------------------
        */

        $paymentsQuery = Payment::query();

        if ($startDate) {
            $paymentsQuery->whereDate('payment_date', '>=', $startDate);
        }

        if ($endDate) {
            $paymentsQuery->whereDate('payment_date', '<=', $endDate);
        }

        $payments = $paymentsQuery
            ->with('customer', 'bill')
            ->latest('payment_date')
            ->get();


        /*
        |--------------------------------------------------------------------------
        | Billing Totals
        |--------------------------------------------------------------------------
        */

        $totalBills = $bills->count();

        $totalBilled = $bills->sum('water_charge');

        $totalPaidAgainstBills = $bills->sum('amount_paid');

        $totalOutstanding = $bills->sum('balance');


        /*
        |--------------------------------------------------------------------------
        | Bill Status Counts
        |--------------------------------------------------------------------------
        */

        $paidBills = $bills
            ->where('status', 'paid')
            ->count();

        $partiallyPaidBills = $bills
            ->where('status', 'partially_paid')
            ->count();

        $unpaidBills = $bills
            ->where('status', 'unpaid')
            ->count();


        /*
        |--------------------------------------------------------------------------
        | Payment Totals
        |--------------------------------------------------------------------------
        */

        $totalPayments = $payments->count();

        $totalCollected = $payments->sum('amount');


        /*
        |--------------------------------------------------------------------------
        | Payment Methods
        |--------------------------------------------------------------------------
        */

        $cashCollected = $payments
            ->where('payment_method', 'cash')
            ->sum('amount');

        $mpesaCollected = $payments
            ->where('payment_method', 'mpesa')
            ->sum('amount');

        $bankCollected = $payments
            ->where('payment_method', 'bank')
            ->sum('amount');


        /*
        |--------------------------------------------------------------------------
        | Return Report
        |--------------------------------------------------------------------------
        */

        return view('reports.index', compact(
            'bills',
            'payments',
            'startDate',
            'endDate',
            'totalBills',
            'totalBilled',
            'totalPaidAgainstBills',
            'totalOutstanding',
            'paidBills',
            'partiallyPaidBills',
            'unpaidBills',
            'totalPayments',
            'totalCollected',
            'cashCollected',
            'mpesaCollected',
            'bankCollected'
        ));
    }
}